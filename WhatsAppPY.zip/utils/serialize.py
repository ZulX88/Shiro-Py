from neonize.utils import get_message_type ,build_jid 

class Mess:
    def __init__(self, client, message):
        self.get_msg_type = get_message_type(message)
        self.sender = message.Info.MessageSource.Sender
        self.senderAlt = message.Info.MessageSource.SenderAlt
        self.chat = message.Info.MessageSource.Chat 
        self.from_me = message.Info.MessageSource.IsFromMe 
        self.is_group = message.Info.MessageSource.IsGroup or self.chat.Server == "g.us"
        self.id = message.Info.ID        
        
        async def reply(text):
            await client.reply_message(text.__str__(),message)
       
       
from utils.serialize import Mess
from neonize.aioze.client import NewAClient, ClientFactory, ContactStore
from neonize.aioze.events import MessageEv
from neonize.proto.waE2E.WAWebProtobufsE2E_pb2 import (
    Message,
    FutureProofMessage,
    InteractiveMessage,
    MessageContextInfo,
    DeviceListMetadata,
)
from neonize.types import MessageServerID
from urllib.parse import quote, urlparse
from scrape.copilot import send_copilot_request 
from scrape.zerochan import zerochan
import re
import config 
import json


async def handler(client: NewAClient, message: MessageEv):
    m = Mess(client,message)
    budy = (
        message.Message.conversation
        or getattr(message.Message, "extendedTextMessage", None) and message.Message.extendedTextMessage.text
        or ""
    )
    prefix_match = re.match(r"^[°•π÷×¶∆£¢€¥®™✓_=|~!?#$%^&.+\-,/\\©^]", budy)
    prefix = prefix_match.group() if prefix_match else "!"
    isCmd = budy.startswith(prefix)
    command = ""
    text = ""
    if isCmd:
        parts = budy[len(prefix):].strip().split(" ", 1)
        command = parts[0].lower()
        if len(parts) > 1:
            text = parts[1]    
    is_group = m.is_group
    groupMetadata = await client.get_group_info(m.chat) if is_group else None    
    isOwner = m.sender.User in config.owner if m.sender.Server == "s.whatsapp.net" else m.senderAlt.User if m.sender.Server == "lid" else None
    is_admin = False
    isBotAdmin = False
    
    if is_group and groupMetadata:
        for participant in groupMetadata.Participants:  
            if participant.JID.User == m.sender.User and (participant.IsAdmin or participant.IsSuperAdmin):
                is_admin = True
            if participant.JID.User == config.bot_number and (participant.IsAdmin or participant.IsSuperAdmin):
                isBotAdmin = True
            if is_admin and isBotAdmin:
                break
                
    def Example(teks):
        return f"*Contoh* : {prefix}{command} " + str(teks)
    
    match command:                 
        case "album":
            await client.send_album(m.chat, ["https://tmpfiles.org/dl/8198352/1753850697073.jpg","https://tmpfiles.org/dl/8198325/1753850689933.jpg","https://tmpfiles.org/dl/8198281/1753850680197.jpg"], "Album")
        case "get_l":
            #jeaidi = build_jid("108070571118660",server="lid")
            #h = await client.get_pn_from_lid(m.senderAlt)
            h = None
            if m.sender.Server == "lid":
                #h = await client.get_pn_from_lid(m.sender)
                return await client.reply_message(m.sender.__str__(),message)
            elif m.senderAlt.Server == "lid":
               # h = await client.get_pn_from_lid(m.senderAlt)
                return await client.reply_message(m.senderAlt.__str__(),message)
            
        case "get_p":
            #jeaidi = build_jid("108070571118660",server="lid")
            #h = await client.get_pn_from_lid(m.senderAlt)
            h = None
            if m.sender.Server == "lid":
                h = await client.get_pn_from_lid(m.sender)
                return await client.reply_message(h.__str__(),message)
            elif m.senderAlt.Server == "lid":
                h = await client.get_pn_from_lid(m.senderAlt)
                return await client.reply_message(h.__str__(),message)
            
        case "hidetag": 
            if not is_admin and not isOwner:
                return await client.reply_message("Only admin!",message)
            if not text:
                return await client.reply_message(Example("teks"),message)
            tagged = ""
            for user in groupMetadata.Participants:
                tagged += f"@{user.JID.User} "
            await client.send_message(m.chat,message=str(text),ghost_mentions=tagged)
        case "mtype":
            typek = get_message_type(message)
            await client.reply_message(str(typek),message)
        case "tt" | "tiktok":
            if not text:
                return await client.reply_message("Masukkan link video/foto TikTok", message)
            
            try:
                parsed = urlparse(text)
                if not all([parsed.scheme, parsed.netloc]):
                    return await client.reply_message("URL tidak valid", message)
                    
                # Encode URL untuk request API
                encoded_url = quote(text, safe='')
                api_url = f"https://tikwm.com/api/?hd=1&url={encoded_url}"
                
                response = requests.get(api_url, timeout=10).json()
                
                if not response.get("data"):
                    return await client.reply_message("Gagal memproses video", message)
                    
                data = response["data"]
                
                if data.get("images"):
                    for image_url in data["images"]:
                        return await client.send_image(m.chat, str(image_url))                     
                await client.send_video(m.chat, await client.build_video_message(data["play"]))
                    
            except requests.exceptions.RequestException:
                await client.reply_message("Error saat menghubungi server", message)
            except ValueError:
                await client.reply_message("Response tidak valid", message)
        case "zero":
            if not text:
                return await client.reply_message(Example("shiroko"),message)
            linkz = zerochan(text)
            #await client.send_message(m.chat,linkz)
            for linkk in linkz:
                await client.send_image(m.chat,linkk)
             
            
        case "copilot":
            if not text:
                return await client.reply_message(Example("bagaimana cara ngoding"),message)
                
            result = json.loads(send_copilot_request(text))
            await client.send_message(m.chat,str(result["text"]))
            
            
        case "cekadmin":
            if not is_admin:
                return await client.reply_message("False",message)
            await client.send_message(m.chat,f"True")
        case "ping":
            await client.reply_message("pong", message)
        case "stop":
            print("Stopping client...")
            await client.stop()
        case "_test_link_preview":
            await client.send_message(
                m.chat, "Test https://github.com/krypton-byte/neonize", link_preview=True
            )
        case "_sticker":
            await client.send_sticker(
                m.chat,
                "https://mystickermania.com/cdn/stickers/anime/spy-family-anya-smirk-512x512.png",
            )
        case "_sticker_exif":
            await client.send_sticker(
                m.chat,
                "https://mystickermania.com/cdn/stickers/anime/spy-family-anya-smirk-512x512.png",
                name="@Neonize",
                packname="2024",
            )
        case "_image":
            await client.send_image(
                m.chat,
                "https://download.samplelib.com/png/sample-boat-400x300.png",
                caption="Test",
                quoted=message,
            )
        case "_video":
            await client.send_video(
                m.chat,
                "https://download.samplelib.com/mp4/sample-5s.mp4",
                caption="Test",
                quoted=message,
            )
        case "_audio":
            await client.send_audio(
                m.chat,
                "https://download.samplelib.com/mp3/sample-12s.mp3",
                quoted=message,
            )
        case "_ptt":
            await client.send_audio(
                m.chat,
                "https://download.samplelib.com/mp3/sample-12s.mp3",
                ptt=True,
                quoted=message,
            )
        case "_doc":
            await client.send_document(
                m.chat,
                "https://download.samplelib.com/xls/sample-heavy-1.xls",
                caption="Test",
                filename="test.xls",
                quoted=message,
            )
        case "debug":
            await client.send_message(build_jid("601164899724"), message.__str__())
        case "viewonce":
            await client.send_image(
                m.chat,
                "https://pbs.twimg.com/media/GC3ywBMb0AAAEWO?format=jpg&name=medium",
                viewonce=True,
            )
        case "profile_pict":
            await client.send_message(m.chat, (await client.get_profile_picture(m.chat)).__str__())
        case "status_privacy":
            await client.send_message(m.chat, (await client.get_status_privacy()).__str__())
        case "read":
            await client.send_message(
                m.chat,
                (
                    await client.mark_read(
                        message.Info.ID,
                        chat=message.Info.MessageSource.Chat,
                        sender=message.Info.MessageSource.Sender,
                        receipt=ReceiptType.READ,
                    )
                ).__str__(),
            )
        case "read_channel":
            metadata = await client.get_newsletter_info_with_invite(
                "https://whatsapp.com/channel/0029Va4K0PZ5a245NkngBA2M"
            )
            err = await client.follow_newsletter(metadata.ID)
            await client.send_message(m.chat, "error: " + err.__str__())
            resp = await client.newsletter_mark_viewed(metadata.ID, [MessageServerID(0)])
            await client.send_message(m.chat, resp.__str__() + "\n" + metadata.__str__())
        case "logout":
            await client.logout()
        case "send_react_channel":
            metadata = await client.get_newsletter_info_with_invite(
                "https://whatsapp.com/channel/0029Va4K0PZ5a245NkngBA2M"
            )
            data_msg = await client.get_newsletter_messages(metadata.ID, 2, MessageServerID(0))
            await client.send_message(m.chat, data_msg.__str__())
            for _ in data_msg:
                await client.newsletter_send_reaction(metadata.ID, MessageServerID(0), "🗿", "")
        case "subscribe_channel_updates":
            metadata = await client.get_newsletter_info_with_invite(
                "https://whatsapp.com/channel/0029Va4K0PZ5a245NkngBA2M"
            )
            result = await client.newsletter_subscribe_live_updates(metadata.ID)
            await client.send_message(m.chat, result.__str__())
        case "mute_channel":
            metadata = await client.get_newsletter_info_with_invite(
                "https://whatsapp.com/channel/0029Va4K0PZ5a245NkngBA2M"
            )
            await client.send_message(
                m.chat,
                (await client.newsletter_toggle_mute(metadata.ID, False)).__str__(),
            )
        case "set_diseapearing":
            await client.send_message(
                m.chat,
                (await client.set_default_disappearing_timer(timedelta(days=7))).__str__(),
            )
        case "test_contacts":
            await client.send_message(m.chat, (await client.contact.get_all_contacts()).__str__())
        case "build_sticker":
            await client.send_message(
                m.chat,
                await client.build_sticker_message(
                    "https://mystickermania.com/cdn/stickers/anime/spy-family-anya-smirk-512x512.png",
                    message,
                    "2024",
                    "neonize",
                ),
            )
        case "build_video":
            await client.send_message(
                m.chat,
                await client.build_video_message(
                    "https://download.samplelib.com/mp4/sample-5s.mp4", "Test", message
                ),
            )
        case "build_image":
            await client.send_message(
                m.chat,
                await client.build_image_message(
                    "https://download.samplelib.com/png/sample-boat-400x300.png",
                    "Test",
                    message,
                ),
            )
        case "build_document":
            await client.send_message(
                m.chat,
                await client.build_document_message(
                    "https://download.samplelib.com/xls/sample-heavy-1.xls",
                    "Test",
                    "title",
                    "sample-heavy-1.xls",
                    quoted=message,
                ),
            )
        # ChatSettingsStore
        case "put_muted_until":
            await client.chat_settings.put_muted_until(m.chat, timedelta(seconds=5))
        case "put_pinned_enable":
            await client.chat_settings.put_pinned(m.chat, True)
        case "put_pinned_disable":
            await client.chat_settings.put_pinned(m.chat, False)
        case "put_archived_enable":
            await client.chat_settings.put_archived(m.chat, True)
        case "put_archived_disable":
            await client.chat_settings.put_archived(m.chat, False)
        case "get_chat_settings":
            await client.send_message(
                m.chat, (await client.chat_settings.get_chat_settings(m.chat)).__str__()
            )
        case "poll_vote":
            await client.send_message(
                m.chat,
                await client.build_poll_vote_creation(
                    "Food",
                    ["Pizza", "Burger", "Sushi"],
                    VoteType.SINGLE,
                ),
            )
        case "wait":
            await client.send_message(m.chat, "Waiting for 5 seconds...")
            await asyncio.sleep(5)
            await client.send_message(m.chat, "Done waiting!")
        case "shutdown":
            event.set()
        case "send_react":
            await client.send_message(
                m.chat,
                await client.build_reaction(
                    m.chat, message.Info.MessageSource.Sender, message.Info.ID, reaction="🗿"
                ),
            )
          
        case "hil":
            await client.send_message(build_jid(m.chat.User, server=str(m.chat.Server)),"HelloWorld")
        case "edit_message":
            text = "Hello World"
            id_msg = None
            for i in range(1, len(text) + 1):
                if id_msg is None:
                    msg = await client.send_message(
                        message.Info.MessageSource.Chat, Message(conversation=text[:i])
                    )
                    id_msg = msg.ID
                await client.edit_message(
                    message.Info.MessageSource.Chat, id_msg, Message(conversation=text[:i])
                )
        case "button":
            await client.send_message(
                message.Info.MessageSource.Chat,
                Message(
                    viewOnceMessage=FutureProofMessage(
                        message=Message(
                            messageContextInfo=MessageContextInfo(
                                deviceListMetadata=DeviceListMetadata(),
                                deviceListMetadataVersion=2,
                            ),
                            interactiveMessage=InteractiveMessage(
                                body=InteractiveMessage.Body(text="Body Message"),
                                footer=InteractiveMessage.Footer(text="@krypton-byte"),
                                header=InteractiveMessage.Header(
                                    title="Title Message",
                                    subtitle="Subtitle Message",
                                    hasMediaAttachment=False,
                                ),
                                nativeFlowMessage=InteractiveMessage.NativeFlowMessage(
                                    buttons=[
                                        InteractiveMessage.NativeFlowMessage.NativeFlowButton(
                                            name="single_select",
                                            buttonParamsJSON='{"title":"List Buttons","sections":[{"title":"title","highlight_label":"label","rows":[{"header":"header","title":"title","description":"description","id":"select 1"},{"header":"header","title":"title","description":"description","id":"select 2"}]}]}',
                                        ),
                                        InteractiveMessage.NativeFlowMessage.NativeFlowButton(
                                            name="quick_reply",
                                            buttonParamsJSON='{"display_text":"Quick URL","url":"https://www.google.com","merchant_url":"https://www.google.com"}',
                                        ),
                                        InteractiveMessage.NativeFlowMessage.NativeFlowButton(
                                            name="cta_call",
                                            buttonParamsJSON='{"display_text":"Quick Call","id":"message"}',
                                        ),
                                        InteractiveMessage.NativeFlowMessage.NativeFlowButton(
                                            name="cta_copy",
                                            buttonParamsJSON='{"display_text":"Quick Copy","id":"123456789","copy_code":"message"}',
                                        ),
                                        InteractiveMessage.NativeFlowMessage.NativeFlowButton(
                                            name="cta_remainder",
                                            buttonParamsJSON='{"display_text":"Reminder","id":"message"}',
                                        ),
                                        InteractiveMessage.NativeFlowMessage.NativeFlowButton(
                                            name="cta_cancel_remainder",
                                            buttonParamsJSON='{"display_text":"Cancel Reminder","id":"message"}',
                                        ),
                                        InteractiveMessage.NativeFlowMessage.NativeFlowButton(
                                            name="address_message",
                                            buttonParamsJSON='{"display_text":"Address","id":"message"}',
                                        ),
                                        InteractiveMessage.NativeFlowMessage.NativeFlowButton(
                                            name="send_location", buttonParamsJSON=""
                                        ),
                                    ]
                                ),
                            ),
                        )
                    )
                ),
            )
